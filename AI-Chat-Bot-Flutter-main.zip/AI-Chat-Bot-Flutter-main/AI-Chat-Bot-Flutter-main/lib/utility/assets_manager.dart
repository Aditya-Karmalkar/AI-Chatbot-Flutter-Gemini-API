class AssetsMenager {
  static const String _images = 'assets/images/';

  // user icon
  static const String userIcon = '${_images}user_icon.png';
}
